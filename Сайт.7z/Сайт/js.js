document.getElementById('feedbackForm').addEventListener('submit', function (event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;
    let numberPhone = document.getElementById('phone').value;
    let old = document.getElementById('tentacles').value;
    let theme = document.getElementById('theme').value;

    console.log(
        `ФИО:${name}
Почта:${email}
Номер телефона:${numberPhone}
Тема консультации:${theme}
Возраст ребенка:${old}
Текст сообщения:${message}
`);




    alert('Сообщение отправлено!');
    this.reset();
});

